#include "Image_processing.hpp"

struct Point_and_Color {
    float point;
    std::string color;
};

bool sort_array( const Point_and_Color& x, const Point_and_Color& y ) {
    return x.point == y.point ? x.color < y.color : x.point < y.point;
}

int main(void){
    ImageProcessing IP;
    
    float red_point = IP.detect_red(IP.hsv_img);
    float blue_point = IP.detect_blue(IP.hsv_img);
    float green_point = IP.detect_green(IP.hsv_img);

    std::vector<Point_and_Color> result;

    result = {{red_point, "RED"},
              {blue_point, "BLUE"},
              {green_point, "GREEN"}};

    sort(result.begin(), result.end(), sort_array);

    for(int i = 0; i < result.size(); i++){
        if(i == 0){
            std::cout << "1st:" << result[i].color << std::endl;
        }else if (i == 1)
        {
            std::cout << "2nd:" << result[i].color << std::endl;
        }else if (i == 2)
        {
            std::cout << "3rd:" << result[i].color << std::endl;
        }
    }




    return 0;
}