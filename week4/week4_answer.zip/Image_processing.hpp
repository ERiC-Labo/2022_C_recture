#pragma once 
#include <iostream>
#include <opencv4/opencv2/opencv.hpp>


class ImageProcessing {
    private:
        std::string path;
        cv::Mat Red_Hose;
        cv::Mat Blue_Hose;
        cv::Mat Green_Hose;

    public:
        ImageProcessing();
        cv::Mat input_img;
        cv::Mat hsv_img;
        void input_image();
        void rgb_to_hsv(cv::Mat img);
        float detect_red(cv::Mat img);
        float detect_blue(cv::Mat img);
        float detect_green(cv::Mat img);
        float centroid_image(cv::Mat mask);
};

