#include "Image_processing.hpp"
#include <iostream>

ImageProcessing::ImageProcessing()
{
    input_image();
    rgb_to_hsv(ImageProcessing::input_img);
}

void ImageProcessing::input_image()
{
    std::cout << "Please enter the path to the image." << std::endl;
    std::cin >> ImageProcessing::path;
    ImageProcessing::input_img = cv::imread(ImageProcessing::path);
    cv::imshow("input_img", ImageProcessing::input_img);
    
}

void ImageProcessing::rgb_to_hsv(cv::Mat img)
{
    cv::cvtColor(img, hsv_img, cv::COLOR_BGR2HSV);
    std::cout << "From BGR To HSV was done." << std::endl;
}

float ImageProcessing::detect_red(cv::Mat img){
    std::vector <int> lower_red;
    std::vector <int> upper_red;
    lower_red = {0, 127, 0};
    upper_red = {10, 255, 255};

    cv::inRange(img, lower_red, upper_red, Red_Hose);
    cv::imshow("red_hose", Red_Hose);

    float point;
    point = centroid_image(Red_Hose);
    
    return point;
    
}

float ImageProcessing::detect_blue(cv::Mat img){
    std::vector <int> lower_blue;
    std::vector <int> upper_blue;
    lower_blue = {110, 50, 50};
    upper_blue = {130, 255, 255};

    cv::inRange(img, lower_blue, upper_blue, Blue_Hose);
    cv::imshow("Blue_hose", Blue_Hose);

    float point;
    point = centroid_image(Blue_Hose);

    return point;
    
}

float ImageProcessing::detect_green(cv::Mat img){
    std::vector <int> lower_green;
    std::vector <int> upper_green;
    lower_green = {50, 100, 100};
    upper_green = {70, 255, 255};

    cv::inRange(img, lower_green, upper_green, Green_Hose);
    cv::imshow("green_hose", Green_Hose);

    float point;
    point = centroid_image(Green_Hose);

    return point;
    
}

float ImageProcessing::centroid_image(cv::Mat mask){
    cv::Moments mu;
    cv::Point2f mc;

    mu = cv::moments(mask, true);
    mc = cv::Point2f(mu.m10/mu.m00, mu.m01/mu.m00);
    
    float result;
    result = (float) mc.x;
    return result;
}

